// Fichier global.dart nettoyé
